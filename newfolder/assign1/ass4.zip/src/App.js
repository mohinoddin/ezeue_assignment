import React from 'react'
import Posts from './components/posts'
const App = () => {
  return (
    <div>
      <Posts/>
    </div>
  )
}

export default App